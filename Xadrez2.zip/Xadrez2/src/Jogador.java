import java.util.ArrayList;

public class Jogador {

    private String nome;
    private String senha;
    private String cor;
    private double pontos;
    private ArrayList<Peca>pecas;

    public boolean moverPeca(
            Peca peca,
            Posicao posicao){
        return true;
    }

    public boolean proporEmpate(
            Jogador jogador){
        return true;
    }

    public void desistir(){

    }

}